import { Modal } from 'antd'
import React, { Component, PropTypes } from 'react'

class RelationModuleModal extends Component {
    constructor(props) {
        super(props)

    }

    render() {
        const {onClose,visible} = this.props
        return (
            <Modal
                title='相关性分析模块'
                visible={false}

            >

            </Modal>
        )
    }
}

RelationModuleModal.propTypes = {

}

export default RelationModuleModal