import React, { Component } from 'react';
import PropTypes from 'prop-types';
import s from './DataFlowView.css';
import { message, Modal } from 'antd';
import HistoryModuleModal from './HistoryModuleModal';
import RelationModuleModal from './RelationModuleModal';
import FilterModuleModal from './FilterModuleModal';

class DataFlowView extends Component {
    constructor(props) {
        super(props);
        const { projects, selectedProjectIndex } = props;
        let projectConfig = { modules: [], connections: [] };

        // 通过逻辑判断获取projectConfig
        if (selectedProjectIndex !== -1 && projects && projects.length > selectedProjectIndex) {
            const selectedProject = projects[selectedProjectIndex];
            if (selectedProject && selectedProject.projectConfig) {
                projectConfig = selectedProject.projectConfig;
            }
        }

        this.state = {
            modules: projectConfig.modules ? projectConfig.modules : [],             // 模块列表
            connections: projectConfig.connections ? projectConfig.connections : [], // 模块连接列表
            draggingModuleId: null,
            tempConnection: null,    // 临时连接线
            canvasOffset: { x: 0, y: 0 }, 
            pendingModuleType: null,
            canvasSize: { width: 0, height: 830 },
            nextModuleId: this.calculateNextModuleId(projectConfig.modules ? projectConfig.modules : []),
            selectedModuleId: null,  // 当前选择的模块id
            historyModalVisible: false,  // 历史数据模块弹框
            relationModalVisible: false, // 相关性分析模块弹框
            filterModalVisible: false,   // 过滤模块弹框
            selectedModule: null,        // 当前双击的模块数据
        };

        // 绑定事件处理函数（移除scale相关逻辑）
        this.handleCanvasClick = this.handleCanvasClick.bind(this);
        this.handleModuleDragStart = this.handleModuleDragStart.bind(this);
        this.handleModuleDrag = this.handleModuleDrag.bind(this);
        this.handleModuleDragEnd = this.handleModuleDragEnd.bind(this);
        this.handleConnectionPointClick = this.handleConnectionPointClick.bind(this);
        this.handleSaveFlowchart = this.handleSaveFlowchart.bind(this);
        this.handleLoadFlowchart = this.handleLoadFlowchart.bind(this);
        this.handleClearFlowchart = this.handleClearFlowchart.bind(this);
        this.handleCanvasMouseDown = this.handleCanvasMouseDown.bind(this);
        this.handleCanvasMouseMove = this.handleCanvasMouseMove.bind(this);
        this.handleWheel = this.handleWheel.bind(this);
        this.handleModuleOptionClick = this.handleModuleOptionClick.bind(this);
        this.handleResize = this.handleResize.bind(this);
        this.handleModuleClick = this.handleModuleClick.bind(this);
        this.handleKeyDown = this.handleKeyDown.bind(this);
        this.handleCanvasContextMenu = this.handleCanvasContextMenu.bind(this);
        this.handleConnectionPointContextMenu = this.handleConnectionPointContextMenu.bind(this);
        // 新增事件处理函数
        this.handleModuleDoubleClick = this.handleModuleDoubleClick.bind(this);
        this.handleCloseModal = this.handleCloseModal.bind(this);
        this.handleModuleUpdate = this.handleModuleUpdate.bind(this);
    }

    // 计算下一个模块 ID
    calculateNextModuleId(modules) {
        if (!modules || modules.length === 0) {
            return 1;
        }
        let maxId = 0;
        for (let i = 0; i < modules.length; i++) {
            const moduleId = parseInt(modules[i].id, 10);
            if (!isNaN(moduleId) && moduleId > maxId) {
                maxId = moduleId;
            }
        }
        return maxId + 1;
    }

    componentDidMount() {
        this.handleResize();
        window.addEventListener('resize', this.handleResize);

        if (this.canvas) {
            this.canvas.addEventListener('mousedown', this.handleCanvasMouseDown);
            this.canvas.addEventListener('mousemove', this.handleCanvasMouseMove);
            this.canvas.addEventListener('wheel', this.handleWheel);
        }
        window.addEventListener('keydown', this.handleKeyDown);
    }

    componentDidUpdate(prevProps) {
        const { projects, selectedProjectIndex } = this.props;
        // 当工程索引变化时重新加载数据
        if (prevProps.selectedProjectIndex !== selectedProjectIndex) {
            // 移除画布事件监听
            if (this.canvas) {
                this.canvas.removeEventListener('mousedown', this.handleCanvasMouseDown);
                this.canvas.removeEventListener('mousemove', this.handleCanvasMouseMove);
                this.canvas.removeEventListener('wheel', this.handleWheel);
            }

            // 获取新选中工程的配置
            let projectConfig = { modules: [], connections: [] };
            if (selectedProjectIndex !== -1 && projects && projects.length > selectedProjectIndex) {
                const selectedProject = projects[selectedProjectIndex];
                if (selectedProject && selectedProject.projectConfig) {
                    projectConfig = selectedProject.projectConfig;
                }
            }

            // 更新状态加载新数据
            this.setState({
                modules: projectConfig.modules ? projectConfig.modules : [],
                connections: projectConfig.connections ? projectConfig.connections : [],
                tempConnection: null,
                pendingModuleType: null,
                nextModuleId: this.calculateNextModuleId(projectConfig.modules ? projectConfig.modules : []),
                selectedModuleId: null,
                historyModalVisible: false,
                relationModalVisible: false,
                filterModalVisible: false,
                selectedModule: null
            }, () => {
                // 重新添加画布事件监听
                if (this.canvas && selectedProjectIndex !== -1) {
                    this.canvas.addEventListener('mousedown', this.handleCanvasMouseDown);
                    this.canvas.addEventListener('mousemove', this.handleCanvasMouseMove);
                    this.canvas.addEventListener('wheel', this.handleWheel);
                }
            });
        }

        if (prevProps.selectedProjectIndex === -1 && selectedProjectIndex !== -1) {
            this.handleResize();
        }
    }

    componentWillUnmount() {
        window.removeEventListener('resize', this.handleResize);

        if (this.canvas) {
            this.canvas.removeEventListener('mousedown', this.handleCanvasMouseDown);
            this.canvas.removeEventListener('mousemove', this.handleCanvasMouseMove);
            this.canvas.removeEventListener('wheel', this.handleWheel);
        }

        window.removeEventListener('keydown', this.handleKeyDown);
    }

    handleResize() {
        if (this.canvasContainer) {
            const { width } = this.canvasContainer.getBoundingClientRect();
            this.setState({
                canvasSize: { width, height: 830 }
            });
        }
    }

    handleModuleOptionClick(e) {
        e.stopPropagation();
        const type = e.currentTarget.dataset.type;
        this.setState({ pendingModuleType: type });
        if (this.canvas) {
            this.canvas.style.cursor = 'crosshair';
        }
    }

    handleCanvasClick(e) {
        const { pendingModuleType, canvasOffset, modules, nextModuleId } = this.state;
        if (!pendingModuleType || !this.canvas) return;

        const rect = this.canvas.getBoundingClientRect();
        const x = (e.clientX - rect.left) - canvasOffset.x;
        const y = (e.clientY - rect.top) - canvasOffset.y;

        const newModule = {
            id: `${nextModuleId}`,
            type: pendingModuleType,
            x: Math.max(10, Math.min(x - 40, this.state.canvasSize.width - 90)),
            y: Math.max(10, Math.min(y - 30, this.state.canvasSize.height - 70)),
            width: 88,
            height: 60
        };

        this.setState({
            modules: [...modules, newModule],
            pendingModuleType: null,
            nextModuleId: nextModuleId + 1
        });

        if (this.canvas) {
            this.canvas.style.cursor = 'default';
        }
    }

    // 右键点击画布空白区域 - 取消临时连接线
    handleCanvasContextMenu(e) {
        e.preventDefault();
        if (e.target.id === 'svgChart') {
            if (this.state.tempConnection) {
                this.setState({ tempConnection: null });
            }
            if (this.state.selectedModuleId) {
                this.setState({ selectedModuleId: null });
            }
        }
    }

    // 右键点击连接点 - 移除相关连接线
    handleConnectionPointContextMenu(e, moduleId, pointType) {
        e.preventDefault();

        const { connections } = this.state;
        const updatedConnections = connections.filter(connection => {
            return !(
                (connection.startModuleId === moduleId && connection.startPointType === pointType) ||
                (connection.endModuleId === moduleId && connection.endPointType === pointType)
            );
        });

        this.setState({
            connections: updatedConnections,
            tempConnection: null
        });

        message.info('已移除相关连接线');
    }

    handleModuleDragStart(e, moduleId) {
        e.preventDefault();
        this.setState({ draggingModuleId: moduleId });
        this.startMouseX = e.clientX;
        this.startMouseY = e.clientY;
        window.addEventListener('mousemove', this.handleModuleDrag);
        window.addEventListener('mouseup', this.handleModuleDragEnd);
    }

    handleModuleDrag(e) {
        const { draggingModuleId, modules, canvasOffset } = this.state;
        if (!draggingModuleId || !this.canvas) return;

        const rect = this.canvas.getBoundingClientRect();
        // 移除scale计算（因scale=1）
        const dx = (e.clientX - this.startMouseX);
        const dy = (e.clientY - this.startMouseY);

        const updatedModules = modules.map(module => {
            if (module.id === draggingModuleId) {
                return {
                    ...module,
                    // 移除scale相关限制计算
                    x: Math.max(0, Math.min(module.x + dx, this.state.canvasSize.width - module.width)),
                    y: Math.max(0, Math.min(module.y + dy, this.state.canvasSize.height - module.height))
                };
            }
            return module;
        });

        this.setState({ modules: updatedModules });
        this.startMouseX = e.clientX;
        this.startMouseY = e.clientY;
    }

    handleModuleDragEnd() {
        this.setState({ draggingModuleId: null });
        window.removeEventListener('mousemove', this.handleModuleDrag);
        window.removeEventListener('mouseup', this.handleModuleDragEnd);
    }

    // 输出输入连接处理
    handleConnectionPointClick(e, moduleId, pointType) {
        e.stopPropagation();
        const { tempConnection, modules } = this.state;
        let module = null;
        for (let i = 0; i < modules.length; i++) {
            if (modules[i].id === moduleId) {
                module = modules[i];
                break;
            }
        }

        if (!module) return;

        const pointX = pointType === 'input'
            ? module.x
            : module.x + module.width;
        const pointY = module.y + module.height / 2;

        if (!tempConnection) {
            this.setState({
                tempConnection: {
                    startModuleId: moduleId,
                    startPointType: pointType,
                    startX: pointX,
                    startY: pointY,
                    endX: pointX,
                    endY: pointY
                }
            });
        } else {
            if (tempConnection.startModuleId !== moduleId) {
                const isValid = (tempConnection.startPointType === 'output' && pointType === 'input');

                if (isValid) {
                    const { connections } = this.state;
                    // 检查重复连接
                    const isDuplicate = connections.some(conn =>
                        conn.startModuleId === tempConnection.startModuleId &&
                        conn.startPointType === tempConnection.startPointType &&
                        conn.endModuleId === moduleId &&
                        conn.endPointType === pointType
                    );

                    if (isDuplicate) {
                        message.info('该连接已存在，无需重复添加');
                        this.setState({ tempConnection: null });
                        return;
                    }

                    const newConnection = {
                        id: `connection_${Date.now()}`,
                        startModuleId: tempConnection.startModuleId,
                        endModuleId: moduleId,
                        startPointType: tempConnection.startPointType,
                        endPointType: pointType
                    };
                    this.setState({
                        connections: [...connections, newConnection],
                        tempConnection: null
                    });
                } else {
                    message.info('请连接输出点到输入点');
                    this.setState({ tempConnection: null });
                }
            } else {
                this.setState({ tempConnection: null });
            }
        }
    }

    handleCanvasMouseMove(e) {
        const { tempConnection, draggingModuleId } = this.state;

        if (draggingModuleId) {
            this.handleModuleDrag(e);
            return;
        }

        if (tempConnection) {
            const rect = this.canvas.getBoundingClientRect();
            const endX = (e.clientX - rect.left) - this.state.canvasOffset.x;
            const endY = (e.clientY - rect.top) - this.state.canvasOffset.y;

            this.setState({
                tempConnection: {
                    ...tempConnection,
                    endX,
                    endY
                }
            });
        }
    }

    handleCanvasMouseDown(e) {
        if (e.target === this.canvas) {
            const rect = this.canvas.getBoundingClientRect();
            this.setState({
                lastMousePos: {
                    x: e.clientX - rect.left,
                    y: e.clientY - rect.top
                }
            });
        } else if (this.state.pendingModuleType) {
            this.handleCanvasClick(e);
        }
    }

    handleWheel(e) {
        e.preventDefault(); // 禁用缩放
    }

    handleSaveFlowchart() {
        const { modules, connections } = this.state;
        const flowchartData = {
            modules: modules,
            connections: connections
        };
        this.props.onSaveFlowchart(flowchartData);
    }

    handleLoadFlowchart() {
        message.info('加载功能已禁用，请使用自己的数据恢复方法。');
    }

    handleClearFlowchart() {
        Modal.confirm({
            title: '提示',
            content: '确定要清空当前流程图吗？点击保存后方可生效。',
            onOk: () => {
                this.setState({
                    modules: [],
                    connections: [],
                    tempConnection: null,
                    pendingModuleType: null,
                    nextModuleId: 1,
                    selectedModuleId: null,
                    historyModalVisible: false,
                    relationModalVisible: false,
                    filterModalVisible: false,
                    selectedModule: null
                });
            }
        })
    }

    getConnectionPoint(moduleId, pointType) {
        const { modules } = this.state;
        let module = null;
        for (let i = 0; i < modules.length; i++) {
            if (modules[i].id === moduleId) {
                module = modules[i];
                break;
            }
        }

        if (!module) return { x: 0, y: 0 };

        return pointType === 'input'
            ? { x: module.x, y: module.y + module.height / 2 }
            : { x: module.x + module.width, y: module.y + module.height / 2 };
    }

    handleModuleClick(moduleId) {
        this.setState({ selectedModuleId: moduleId });
    }

    handleKeyDown(e) {
        if (e.key === 'Delete') {
            const { selectedModuleId, modules, connections } = this.state;
            if (selectedModuleId) {
                const updatedModules = modules.filter(module => module.id !== selectedModuleId);
                const updatedConnections = connections.filter(connection =>
                    connection.startModuleId !== selectedModuleId && connection.endModuleId !== selectedModuleId
                );
                this.setState({
                    modules: updatedModules,
                    connections: updatedConnections,
                    selectedModuleId: null,
                    historyModalVisible: false,
                    relationModalVisible: false,
                    filterModalVisible: false,
                    selectedModule: null
                });
            }
        }
    }

    // 双击模块处理函数
    handleModuleDoubleClick(moduleId) {
        // 找到对应的模块数据
        const module = this.state.modules.find(m => m.id === moduleId);
        if (!module) return;

        // 根据模块类型显示对应的弹框
        this.setState({
            selectedModule: { ...module }, // 深拷贝模块数据
            historyModalVisible: module.type === 'history',
            relationModalVisible: module.type === 'relation',
            filterModalVisible: module.type === 'filter'
        });
    }

    // 关闭弹框
    handleCloseModal() {
        this.setState({
            historyModalVisible: false,
            relationModalVisible: false,
            filterModalVisible: false,
            selectedModule: null
        });
    }

    // 接收子组件更新的模块数据
    handleModuleUpdate(updatedModule) {
        if (!updatedModule || !updatedModule.id) return;

        // 更新模块列表中对应的数据
        const updatedModules = this.state.modules.map(module => 
            module.id === updatedModule.id ? { ...updatedModule } : module
        );

        this.setState({
            modules: updatedModules,
            historyModalVisible: false,
            relationModalVisible: false,
            filterModalVisible: false,
            selectedModule: null
        });
    }

    render() {
        const {
            modules,
            connections,
            tempConnection,
            canvasOffset,
            pendingModuleType,
            canvasSize,
            selectedModuleId,
            filterModalVisible,
            relationModalVisible,
            historyModalVisible,
            selectedModule
        } = this.state;
        const { selectedProjectIndex, projects } = this.props;

        const moduleTypeMap = {
            history: '历史数据',
            filter: '数据过滤',
            relation: '相关性分析'
        };

        if (selectedProjectIndex === -1) {
            return (
                <div style={{ padding: 5 }}>
                    <h2 style={{ color: '#333' }}>未选择工程</h2>
                    <p>请从左侧选择一个数据分析工程以查看和编辑数据流图</p>
                </div>
            );
        }

        let projectName = '未知工程';
        if (projects && projects.length > selectedProjectIndex && projects[selectedProjectIndex]) {
            projectName = projects[selectedProjectIndex].projectName || '未知工程';
        }

        return (
            <div>
                <header className={s['app-header']}>
                    <div>
                        <button onClick={this.handleSaveFlowchart} className={s['action-btn'] + ' ' + s['save-btn']}>
                            保存
                        </button>
                        <button onClick={this.handleClearFlowchart} className={s['action-btn'] + ' ' + s['clear-btn']}>
                            清空
                        </button>
                        <button
                            className={`${s['action-btn']} ${pendingModuleType === 'history' ? s['selected'] : ''}`}
                            data-type="history"
                            onClick={this.handleModuleOptionClick}
                        >
                            历史数据模块
                        </button>
                        <button
                            className={`${s['action-btn']} ${pendingModuleType === 'filter' ? s['selected'] : ''}`}
                            data-type="filter"
                            onClick={this.handleModuleOptionClick}
                        >
                            数据过滤模块
                        </button>
                        <button
                            className={`${s['action-btn']} ${pendingModuleType === 'relation' ? s['selected'] : ''}`}
                            data-type="relation"
                            onClick={this.handleModuleOptionClick}
                        >
                            相关性分析模块
                        </button>
                        <span style={{ display: 'inline-block', marginLeft: 20 }}>当前工程: {projectName}</span>
                    </div>
                </header>

                <div ref={ref => this.canvasContainer = ref}>
                    <svg
                        ref={ref => this.canvas = ref}
                        width={canvasSize.width}
                        height={canvasSize.height}
                        onClick={this.handleCanvasClick}
                        onContextMenu={this.handleCanvasContextMenu}
                    >
                        <defs>
                            <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                                <polygon points="0 0, 10 3.5, 0 7" fill="#666" />
                            </marker>
                        </defs>
                        <g transform={`translate(${canvasOffset.x}, ${canvasOffset.y})`}>
                            <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                                <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#f0f0f0" strokeWidth="0.5" />
                            </pattern>
                            <rect width="100%" height="100%" id='svgChart' fill="url(#grid)" />

                            <g id="connections">
                                {connections.map(connection => {
                                    const startPoint = this.getConnectionPoint(connection.startModuleId, connection.startPointType);
                                    const endPoint = this.getConnectionPoint(connection.endModuleId, connection.endPointType);

                                    return (
                                        <path
                                            key={connection.id}
                                            d={`M ${startPoint.x} ${startPoint.y} L ${endPoint.x} ${endPoint.y}`}
                                            stroke="#666"
                                            strokeWidth="2"
                                            fill="none"
                                            markerEnd="url(#arrowhead)"
                                        />
                                    );
                                })}

                                {tempConnection && (
                                    <path
                                        d={`M ${tempConnection.startX} ${tempConnection.startY} L ${tempConnection.endX} ${tempConnection.endY}`}
                                        stroke="#666"
                                        strokeWidth="2"
                                        strokeDasharray="5,5"
                                        fill="none"
                                    />
                                )}
                            </g>

                            <g id="modules">
                                {modules.map(module => (
                                    <g
                                        key={module.id}
                                        onMouseDown={e => this.handleModuleDragStart(e, module.id)}
                                        onMouseUp={this.handleModuleDragEnd}
                                        onClick={() => this.handleModuleClick(module.id)}
                                        onDoubleClick={() => this.handleModuleDoubleClick(module.id)} // 双击事件
                                        className={this.state.draggingModuleId === module.id ? s['dragging'] : ''}
                                    >
                                        <rect
                                            x={module.x}
                                            y={module.y}
                                            width={module.width}
                                            height={module.height}
                                            rx="4"
                                            ry="4"
                                            stroke="#333"
                                            strokeWidth="2"
                                            fill={selectedModuleId === module.id ? '#CCFFFF' : 'white'}
                                        />

                                        <text
                                            x={module.x + module.width / 2}
                                            y={module.y + module.height / 2}
                                            textAnchor="middle"
                                            dominantBaseline="middle"
                                            fill="#333"
                                            fontSize="14"
                                            fontWeight="500"
                                        >
                                            {moduleTypeMap[module.type] || module.type}
                                        </text>

                                        <circle
                                            cx={module.x}
                                            cy={module.y + module.height / 2}
                                            r="6"
                                            fill="white"
                                            stroke="#666"
                                            strokeWidth="2"
                                            className={s['connection-point'] + ' ' + s['input']}
                                            onClick={e => this.handleConnectionPointClick(e, module.id, 'input')}
                                            onContextMenu={e => this.handleConnectionPointContextMenu(e, module.id, 'input')}
                                        />

                                        <circle
                                            cx={module.x + module.width}
                                            cy={module.y + module.height / 2}
                                            r="6"
                                            fill="white"
                                            stroke="#666"
                                            strokeWidth="2"
                                            className={s['connection-point'] + ' ' + s['output']}
                                            onClick={e => this.handleConnectionPointClick(e, module.id, 'output')}
                                            onContextMenu={e => this.handleConnectionPointContextMenu(e, module.id, 'output')}
                                        />
                                    </g>
                                ))}
                            </g>
                        </g>
                    </svg>
                </div>

                {/* 历史数据模块弹框 */}
                <HistoryModuleModal
                    visible={historyModalVisible}
                    moduleData={selectedModule}
                    onClose={this.handleCloseModal}
                    onUpdate={this.handleModuleUpdate}
                />

                {/* 相关性分析模块弹框 */}
                <RelationModuleModal
                    visible={relationModalVisible}
                    moduleData={selectedModule}
                    onClose={this.handleCloseModal}
                    onUpdate={this.handleModuleUpdate}
                />

                {/* 数据过滤模块弹框 */}
                <FilterModuleModal
                    visible={filterModalVisible}
                    moduleData={selectedModule}
                    onClose={this.handleCloseModal}
                    onUpdate={this.handleModuleUpdate}
                />
            </div>
        );
    }
}


DataFlowView.propTypes = {
    selectedProjectIndex: PropTypes.number,
    projects: PropTypes.arrayOf(PropTypes.shape({
        projectName: PropTypes.string,
        projectConfig: PropTypes.shape({
            modules: PropTypes.arrayOf(PropTypes.shape({
                id: PropTypes.string,
                type: PropTypes.string,
                x: PropTypes.number,
                y: PropTypes.number,
                width: PropTypes.number,
                height: PropTypes.number
            })),
            connections: PropTypes.arrayOf(PropTypes.shape({
                id: PropTypes.string,
                startModuleId: PropTypes.string,
                endModuleId: PropTypes.string,
                startPointType: PropTypes.string,
                endPointType: PropTypes.string
            }))
        })
    })),
    onSaveFlowchart: PropTypes.func.isRequired
};

export default DataFlowView;