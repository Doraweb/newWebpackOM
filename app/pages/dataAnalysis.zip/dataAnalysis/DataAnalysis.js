import React, { Component } from 'react'
import { Button, Input, Layout, message, Modal, Icon, Empty, Spin } from 'antd';
import http from '../../common/http';
import appConfig from '../../common/appConfig';
import s from './DataAnalysis.css';
import { color } from 'echarts';
import DataFlowView from './DataFlowView';

const { Header, Sider, Content } = Layout;

//新增数据分析工程
class AddDataAnalysisJsonModal extends Component {
    constructor(props) {
        super(props)
        this.state = {
            projectName: ''
        }
    }

    onOk = () => {
        const { projectName } = this.state
        if (projectName === '' || projectName.trim() === '') {
            Modal.info({
                title: '提示',
                content: '请输入数据分析工程名称'
            })
            return
        }
        this.setState({
            projectName: ''
        })
        this.props.addNewDataAnalysisProject(projectName.trim())
        this.props.handleCancel(false)
    }

    //工程名
    inputValue = (e) => {
        this.setState({
            projectName: e.target.value
        })
    }

    render() {
        const { visible, handleCancel } = this.props
        const { projectName } = this.state
        return (
            <Modal
                title='新建数据分析工程'
                visible={visible}
                onCancel={() => handleCancel(false)}
                maskClosable={false}
                onOk={this.onOk}
                okText='创建'
                width={300}
            >
                工程名称：<Input onChange={this.inputValue} style={{ width: 160 }} placeholder='请输入工程名称' value={projectName} />
            </Modal>
        )
    }
}

//编辑数据分析工程
class EditDataAnalysisJsonModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            projectName: props.projectName || ''
        };
    }

    // 当接收到新的props时，更新状态中的projectName
    componentWillReceiveProps(nextProps) {
        if (nextProps.projectName !== this.props.projectName) {
            this.setState({
                projectName: nextProps.projectName || ''
            });
        }
    }

    onOk = () => {
        const { projectName } = this.state;
        if (projectName === '' || projectName.trim() === '') {
            Modal.info({
                title: '提示',
                content: '请输入数据分析工程名称'
            });
            return;
        }
        this.props.editDataAnalysisProject(this.props.index, projectName.trim());
        this.props.handleCancel(false);
    };

    // 工程名
    inputValue = (e) => {
        this.setState({
            projectName: e.target.value
        });
    };

    render() {
        const { visible, handleCancel } = this.props;
        const { projectName } = this.state;
        return (
            <Modal
                title='编辑数据分析工程'
                visible={visible}
                onCancel={() => handleCancel(false)}
                maskClosable={false}
                onOk={this.onOk}
                okText='保存'
                width={300}
            >
                工程名称：<Input onChange={this.inputValue} style={{ width: 160 }} placeholder='请输入工程名称' value={projectName} />
            </Modal>
        );
    }
}

class DataAnalysis extends Component {
    constructor(props) {
        super(props)
        this.state = {
            addProjectVisible: false,
            editProjectVisible: false,
            editProjectIndex: -1,
            dataJson: {},    //接口获取的原始数据
            loading: false,    //当原始json数据变动时使用的loading
            selectedProjectIndex: -1
        }
    }

    componentDidMount() {
        this.setState({
            loading: true
        })
        this.getDataAnalysisJson()
    }

    shouldComponentUpdate(nextProps, nextState) {
        if (this.state.addProjectVisible != nextState.addProjectVisible) {
            return true
        }
        if (this.state.editProjectVisible != nextState.editProjectVisible) {
            return true
        }
        if (this.state.editProjectIndex != nextState.editProjectIndex) {
            return true
        }
        if (this.state.selectedProjectIndex != nextState.selectedProjectIndex) {
            return true
        }
        if (this.state.loading != nextState.loading) {
            return true
        }
        if (JSON.stringify(this.state.dataJson) != JSON.stringify(nextState.dataJson)) {
            return true
        }
        return false
    }

    //获取json内容
    getDataAnalysisJson = () => {
        const key = 'data_analysis_' + appConfig.userData.name
        http.post('/project/getConfigMul', {
            keyList: [key]
        }).then(res => {
            if (res.status) {
                this.setState({
                    dataJson: res.data[key] ? res.data[key] : {},
                    loading: false
                })
            } else {
                this.setState({
                    dataJson: {},
                    loading: false
                })
                Modal.info({
                    title: '提示',
                    content: res.msg
                })
            }
        }).catch(err => {
            Modal.warning({
                title: '提示',
                content: err.message
            })
            this.setState({
                dataJson: {},
                loading: false
            })
        })
    }

    //新建工程弹框
    addDataAnalysisProject = (value) => {
        this.setState({
            addProjectVisible: value
        })
    }

    // 编辑工程弹框
    editDataAnalysisProjectModal = (index, value) => {
        this.setState({
            editProjectVisible: value,
            editProjectIndex: index
        })
    }

    //新建工程
    addNewDataAnalysisProject = (projectName) => {
        const { dataJson } = this.state
        const newDataJson = JSON.parse(JSON.stringify(dataJson))
        if (newDataJson['data']) {
            newDataJson['data'].push({
                projectName: projectName,
                projectConfig: {}
            })
        } else {
            newDataJson['data'] = [{
                projectName: projectName,
                projectConfig: {}
            }]
        }
        this.saveDataAnalysisConfig(newDataJson)
    }

    // 编辑工程
    editDataAnalysisProject = (index, projectName) => {
        const { dataJson } = this.state;
        const newDataJson = JSON.parse(JSON.stringify(dataJson));
        if (newDataJson['data'] && newDataJson['data'][index]) {
            newDataJson['data'][index].projectName = projectName;
        }
        this.saveDataAnalysisConfig(newDataJson)
    }

    // 删除工程
    deleteDataAnalysisProject = (index) => {
        Modal.confirm({
            title: '提示',
            content: '是否要删除该数据分析工程？',
            okType: 'danger',
            icon: <Icon type="delete" style={{ color: 'red' }} />,
            onOk: () => {
                const { dataJson, selectedProjectIndex } = this.state;
                const newDataJson = JSON.parse(JSON.stringify(dataJson));
                if (newDataJson['data'] && newDataJson['data'][index] !== undefined) {
                    newDataJson['data'].splice(index, 1);
                }
                this.saveDataAnalysisConfig(newDataJson, () => {
                    // 回调函数在保存成功后执行
                    // 只有当删除的是当前选中的工程时才重置选中状态
                    if (index === selectedProjectIndex) {
                        this.setState({ selectedProjectIndex: -1 });
                    }
                });
            }
        })
    }

    //存储配置
    saveDataAnalysisConfig = (data, callback) => {
        this.setState({
            loading: true
        });
        http.post('/project/saveConfig', {
            key: 'data_analysis_' + appConfig.userData.name,
            config: JSON.stringify(data)
        }).then(res => {
            if (res.status) {
                message.success('操作成功');
                this.getDataAnalysisJson();
                // 执行回调函数
                if (typeof callback === 'function') {
                    callback();
                }
            } else {
                Modal.info({
                    title: '提示',
                    content: res.msg
                });
                this.setState({
                    loading: false
                });
            }
        }).catch(err => {
            Modal.warning({
                title: '提示',
                content: err.message
            });
            this.setState({
                loading: false
            });
        });
    }

    //点击工程行的处理函数
    handleProjectClick = (index) => {
        this.setState({
            selectedProjectIndex: index
        })
    }

    //接收子组件传回的流程图数据，并保存到projectConfig中
    handleFlowchartSave = (flowchartData) => {
        const { dataJson, selectedProjectIndex } = this.state;
        if (selectedProjectIndex === -1) return;

        // 创建新的dataJson副本
        const newDataJson = JSON.parse(JSON.stringify(dataJson));

        // 将流程图数据保存到对应项目的projectConfig中
        newDataJson.data[selectedProjectIndex].projectConfig = flowchartData

        // 打印结果
        console.log('保存的流程图数据:', newDataJson.data[selectedProjectIndex].projectConfig);

        // 保存到服务器（可选）
        this.saveDataAnalysisConfig(newDataJson);
    }

    render() {
        const { addProjectVisible, editProjectVisible, editProjectIndex, dataJson, loading, selectedProjectIndex } = this.state
        const projects = dataJson.data || [];
        return (
            <div>
                <Spin spinning={loading}>
                    <Layout style={{ height: 945 }}>
                        <Header style={{ background: 'rgb(250,250,250)' }}>
                            <div>
                                <Button onClick={() => this.addDataAnalysisProject(true)}>新建工程</Button>
                                <Button style={{ marginLeft: 20 }} icon='play-circle' type='primary'>运行</Button>
                            </div>
                        </Header>
                        <Layout>
                            <Sider width={240} style={{ background: 'rgb(245,245,245)' }}>
                                <div>
                                    <div className={s['slider_title']}>
                                        数据分析工程列表
                                    </div>
                                    {projects.map((project, index) => (
                                        <div
                                            key={index}
                                            className={`${s["project_item"]} ${selectedProjectIndex === index ? s["project_item_selected"] : ''}`}
                                            onClick={() => this.handleProjectClick(index)}
                                            style={{ cursor: 'pointer' }}
                                        >
                                            <div className={s['project_title']}>
                                                {project.projectName}
                                            </div>
                                            <div className={s['project_icon']}>
                                                <Icon type="edit" className={s['btn_icon']} onClick={(e) => {
                                                    e.stopPropagation()
                                                    this.editDataAnalysisProjectModal(index, true)
                                                }} />
                                                <Icon type="delete" className={s['btn_icon']} onClick={(e) => {
                                                    e.stopPropagation()
                                                    this.deleteDataAnalysisProject(index)
                                                }} />
                                            </div>
                                        </div>
                                    ))}
                                    {projects.length === 0 && (
                                        <Empty />
                                    )}
                                </div>
                            </Sider>
                            <Content style={{ background: 'rgb(210,210,210)', color: '#333' }}>
                                <DataFlowView
                                    projects={projects}
                                    selectedProjectIndex={selectedProjectIndex}
                                    onSaveFlowchart={this.handleFlowchartSave}
                                />
                            </Content>
                        </Layout>
                    </Layout>
                </Spin>
                <AddDataAnalysisJsonModal
                    visible={addProjectVisible}
                    handleCancel={this.addDataAnalysisProject}
                    addNewDataAnalysisProject={this.addNewDataAnalysisProject}
                />
                <EditDataAnalysisJsonModal
                    visible={editProjectVisible}
                    projectName={projects[editProjectIndex] ? projects[editProjectIndex].projectName : ''}
                    index={editProjectIndex}
                    handleCancel={() => this.editDataAnalysisProjectModal(editProjectIndex, false)}
                    editDataAnalysisProject={this.editDataAnalysisProject}
                />
            </div>
        )
    }
}

export default DataAnalysis