import { Modal } from 'antd'
import React, { Component, PropTypes } from 'react'

class FilterModuleModal extends Component {
    constructor(props) {
        super(props)

    }

    render() {
        const {onClose,visible} = this.props
        return (
            <Modal
                title='数据过滤模块'
                visible={false}
                onCancel={onClose}
                maskClosable={false}
            >

            </Modal>
        )
    }
}

FilterModuleModal.propTypes = {

}

export default FilterModuleModal