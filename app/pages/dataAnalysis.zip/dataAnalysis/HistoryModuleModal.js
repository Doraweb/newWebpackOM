import React, { Component } from 'react'
import { Form, Modal, Input } from 'antd'

const FormItem = Form.Item
const formItemLayout = {
    labelCol: {
        xs: { span: 12 },
        sm: { span: 6 },
    },
    wrapperCol: {
        xs: { span: 14 },
        sm: { span: 16 },
    },
}

//历史数据模块
class HistoryModuleModalView extends Component {
    constructor(props) {
        super(props)

    }

    handleSubmit = (e) => {
        e.preventDefault();
        this.props.form.validateFields((err, values) => {
            if (!err) {
                const { moduleData, onUpdate, onClose } = this.props;

                // 合并表单数据到模块数据
                const updatedModule = {
                    ...moduleData,
                    // 新增配置参数
                    config: {
                        ...(moduleData.config || {}),
                        test1: values.test1,
                        test2: values.test2
                    }
                };

                // 调用父组件的更新回调
                onUpdate(updatedModule);
                // 关闭弹框
                onClose();
            }
        })
    }

    render() {
        const { onClose, visible, form } = this.props
        const { getFieldDecorator } = form
        return (
            <Modal
                title='历史数据模块'
                visible={visible}
                onCancel={onClose}
                onOk={this.handleSubmit}
                maskClosable={false}
                width={400}
            >
                <Form>
                    <FormItem
                        label="选择点"
                        {...formItemLayout}
                        style={{ marginBottom: 10 }}
                    >
                        {getFieldDecorator('test1', {
                            rules: [{ required: true, message: '请填写' }]
                        })(
                            <Input />
                        )}
                    </FormItem>
                    <FormItem
                        label="测试2"
                        {...formItemLayout}
                        style={{ marginBottom: 0 }}
                    >
                        {getFieldDecorator('test2', {
                            rules: [{ required: true, message: '请填写' }]
                        })(
                            <Input />
                        )}
                    </FormItem>
                </Form>
            </Modal>
        )
    }
}

const HistoryModuleModal = Form.create({
    mapPropsToFields: function (props) {
        return {
            test1: Form.createFormField({
                value: props.moduleData && props.moduleData.config ? props.moduleData.config['test1'] : ''
            }),
            test2: Form.createFormField({
                value: props.moduleData && props.moduleData.config ? props.moduleData.config['test2'] : ''
            }),
        }
    }
})(HistoryModuleModalView)

export default HistoryModuleModal